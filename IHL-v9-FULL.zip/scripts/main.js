
function toggleMenu() {
  document.getElementById("side-menu").classList.toggle("active");
}
function toggleDarkMode() {
  document.body.classList.toggle("dark");
}
